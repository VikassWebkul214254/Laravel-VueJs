import './bootstrap';
import {createApp} from 'vue'
import App from './Component/App.vue'

createApp(App).mount("#app")